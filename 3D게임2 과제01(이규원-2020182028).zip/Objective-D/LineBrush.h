#pragma once
#include "DirectX_3D.h"

class LineBrush {
public:
	XMFLOAT4X4 TranslateMatrix{};
	XMFLOAT4X4 ScaleMatrix{};
	XMFLOAT3 LineColor{};
	float TransparencyValue{ 1.0f };

	float Length{}, Rotation{};

	// ���� ������ �����Ѵ�.
	void SetColor(float R, float G, float B);
	void Init(ID3D12GraphicsCommandList* CmdList);
	void Draw(ID3D12GraphicsCommandList* CmdList, float X1, float Y1, float X2, float Y2, float Width, float Alpha=1.0f);
};